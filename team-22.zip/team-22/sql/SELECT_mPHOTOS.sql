SELECT source
FROM PHOTOS, [USER]
WHERE [USER].privacy='OPEN' OR [USER].privacy='NETWORK' OR [USER].privacy='FRIEND'