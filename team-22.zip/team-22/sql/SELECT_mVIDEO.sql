SELECT message 
FROM VIDEO ,[USER]
WHERE [USER].privacy='OPEN' OR [USER].privacy='NETWORK' OR [USER].privacy='FRIEND'