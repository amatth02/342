SELECT name
FROM ALBUM
WHERE privacy='OPEN' OR privacy='NETWORK' OR privacy='FRIEND'