USE [gandre03]

GO

 

ALTER PROC [gandre03].[streq]
              @userID int,@friendID int,@rejected int,@ignore int
AS

              BEGIN

                           INSERT INTO [dbo].[REQUESTS]

                           (

                                         userID,friendID,rejected,ignore

                           )

                           VALUES (
						    @userID,@friendID,@rejected,@ignore
                           )

              END